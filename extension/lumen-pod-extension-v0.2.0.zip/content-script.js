(function(){"use strict";function a(n){try{const e=new URL(n);if(e.hostname==="www.youtube.com"||e.hostname==="youtube.com")return e.searchParams.get("v");if(e.hostname==="youtu.be")return e.pathname.slice(1)||null}catch{}return null}let r=null,t=null;function i(){const n=a(window.location.href);if(n!==r){if(r=n,!n){o();return}chrome.runtime.sendMessage({type:"LOOKUP_VIDEO",videoId:n,url:window.location.href},e=>{chrome.runtime.lastError||((e==null?void 0:e.type)==="LOOKUP_RESULT"&&e.found?d(e.title??"View in Lumen Pod"):o())})}}function d(n){o(),t=document.createElement("div"),t.id="lumen-pod-indicator",t.innerHTML=`
    <div style="
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 99999;
      background: linear-gradient(135deg, #3B82F6, #6366F1);
      color: white;
      padding: 10px 16px;
      border-radius: 12px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      box-shadow: 0 4px 20px rgba(59, 130, 246, 0.4);
      display: flex;
      align-items: center;
      gap: 8px;
      transition: transform 0.2s, box-shadow 0.2s;
      max-width: 300px;
    " id="lumen-pod-indicator-inner">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <polygon points="10 8 16 12 10 16 10 8"></polygon>
      </svg>
      <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
        ${l(n)}
      </span>
    </div>
  `;const e=t.querySelector("#lumen-pod-indicator-inner");e&&(e.addEventListener("mouseenter",()=>{e.style.transform="scale(1.05)",e.style.boxShadow="0 6px 24px rgba(59, 130, 246, 0.5)"}),e.addEventListener("mouseleave",()=>{e.style.transform="scale(1)",e.style.boxShadow="0 4px 20px rgba(59, 130, 246, 0.4)"}),e.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_SIDE_PANEL"})})),document.body.appendChild(t),setTimeout(()=>{t&&(t.style.transition="opacity 0.5s",t.style.opacity="0",setTimeout(o,500))},8e3)}function o(){t&&(t.remove(),t=null)}function l(n){const e=document.createElement("div");return e.textContent=n,e.innerHTML}i(),document.addEventListener("yt-navigate-finish",()=>{setTimeout(i,300)});const c=new MutationObserver(()=>{i()}),s=document.querySelector("title");s&&c.observe(s,{childList:!0}),window.addEventListener("popstate",()=>{setTimeout(i,200)})})();
